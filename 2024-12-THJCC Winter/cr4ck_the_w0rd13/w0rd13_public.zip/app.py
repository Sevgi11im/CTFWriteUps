import os
import requests
from flask import Flask, request, session, render_template

app = Flask(__name__, static_url_path='/')
app.secret_key = os.getenv('secret') or 'TEST'

SPECIALWORD = ['',''] # a lot of char
FLAG = 'THJCC{FAKE_FLAG}'

@app.route('/')
def root():
    return render_template('index.html')


@app.route('/api')
def apiroot():
    return {"success": True,"api":{'/new':'renew a challenge','/check':'post a answer and check answer'}}

@app.route('/api/new')
def new():
    answer = requests.get('https://random-word-api.herokuapp.com/word?length=5').json()[0]
    session['answer'] = answer
    return {'success': True}

@app.route('/api/check', methods=['POST'])
def check():
    answer = session.get('answer')
    guess = request.json['answer']
    
    if guess==SPECIALWORD:
        return {'success':True, 'msg':FLAG}
    
    if not answer or not guess:
        return {'success': False, 'msg': 'missing answer'}
    if not len(guess)==5:
        return {'success': False, 'msg':'wrong length'}
    return check_answer(answer, guess)

def check_answer(answer, submit):
    ans = list(map(str.upper,answer))
    print(ans)
    buf = {}
    ret = []
    for i in range(len(submit)):
        if submit[i] in ans and buf.get(submit[i], 0) < ans.count(submit[i]):
            if submit[i] == ans[i]:
                ret.append(2)
            else:
                ret.append(1)
            buf[submit[i]] = buf.get(submit[i], 0) + 1
        else:
            ret.append(0)
    return {'success': True, 'result': ret}

if __name__ == '__main__':
    app.run('0.0.0.0', port=80)